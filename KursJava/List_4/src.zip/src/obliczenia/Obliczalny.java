package obliczenia;

public interface Obliczalny {
    public int oblicz();
}
