package com.company;

public class Main {

    public static void main(String[] args) {
        Punkt A = new Punkt(2,2);
        Punkt B = new Punkt(3,4);
        Punkt C = new Punkt(-2,-7);
        Odcinek odc = new Odcinek(B,C);
        Trojkat tr = new Trojkat(A,B,C);
        Prosta pr = new Prosta(2,3,-3);
        Wektor wek = new Wektor(2,2);

        System.out.println(A.toString());
        A.odbij(pr);
        System.out.println(A.toString());

        

//        try{
//            Trojkat tr2 = new Trojkat(A, new Punkt(1,2), new Punkt(1,7));
//        }catch (Exception e){
//            e.printStackTrace();
//        }

    }

}
